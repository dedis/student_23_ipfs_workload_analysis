# Database Structure - Nebula Network Crawl Datasets (19.11.2021)

This database contains 20 tables.

--------------------
## Table: visits
### Number of entries: 75'287'986

### Columns and data types:
- id: integer
- peer_id: integer
- crawl_id: integer
- session_id: integer
- dial_duration: interval
- connect_duration: interval
- crawl_duration: interval
- visit_started_at: timestamp with time zone
- visit_ended_at: timestamp with time zone
- updated_at: timestamp with time zone
- created_at: timestamp with time zone
- type: USER-DEFINED
- error: USER-DEFINED
- protocols_set_id: integer
- agent_version_id: integer
- multi_addresses_set_id: integer


--------------------
## Table: peers
### Number of entries: 599'335

### Columns and data types:
- multi_hash: text
- updated_at: timestamp with time zone
- created_at: timestamp with time zone
- id: integer
- protocols_set_id: integer
- agent_version_id: integer


--------------------
## Table: sessions
### Number of entries: 3'938'215

### Columns and data types:
- id: integer
- peer_id: integer
- first_successful_dial: timestamp with time zone
- last_successful_dial: timestamp with time zone
- next_dial_attempt: timestamp with time zone
- first_failed_dial: timestamp with time zone
- min_duration: interval
- max_duration: interval
- successful_dials: integer
- finish_reason: USER-DEFINED
- updated_at: timestamp with time zone
- created_at: timestamp with time zone
- finished: boolean


--------------------
## Table: ip_addresses
### Number of entries: 719'459

### Columns and data types:
- id: integer
- updated_at: timestamp with time zone
- created_at: timestamp with time zone
- country: character varying
- address_sym_encrypted: text


--------------------
## Table: peers_x_multi_addresses
### Number of entries: 1'211'071

### Columns and data types:
- peer_id: integer
- multi_address_id: integer


--------------------
## Table: latencies
### Number of entries: 18'260

### Columns and data types:
- id: integer
- peer_id: integer
- ping_latency_s_avg: double precision
- ping_latency_s_std: double precision
- ping_latency_s_min: double precision
- ping_latency_s_max: double precision
- ping_packets_sent: integer
- ping_packets_recv: integer
- ping_packets_dupl: integer
- ping_packet_loss: double precision
- updated_at: timestamp with time zone
- created_at: timestamp with time zone
- address: text


--------------------
## Table: crawls
### Number of entries: 6'725

### Columns and data types:
- id: integer
- state: USER-DEFINED
- started_at: timestamp with time zone
- finished_at: timestamp with time zone
- updated_at: timestamp with time zone
- created_at: timestamp with time zone
- crawled_peers: integer
- dialable_peers: integer
- undialable_peers: integer


--------------------
## Table: crawl_properties
### Number of entries: 1'494'667

### Columns and data types:
- id: integer
- crawl_id: integer
- protocol_id: integer
- agent_version_id: integer
- error: USER-DEFINED
- count: integer
- created_at: timestamp with time zone
- updated_at: timestamp with time zone


--------------------
## Table: peer_id_sequence
### Number of entries: 599'335

### Columns and data types:
- pg_get_serial_sequence: text


--------------------
## Table: multi_addresses_sets
### Number of entries: 2'320'530

### Columns and data types:
- id: integer
- created_at: timestamp with time zone
- updated_at: timestamp with time zone
- multi_address_ids: ARRAY


--------------------
## Table: agent_versions
### Number of entries: 512

### Columns and data types:
- id: integer
- updated_at: timestamp with time zone
- created_at: timestamp with time zone
- agent_version: text


--------------------
## Table: protocols_sets
### Number of entries: 237

### Columns and data types:
- id: integer
- protocol_ids: ARRAY


--------------------
## Table: schema_migrations
### Number of entries: 1

### Columns and data types:
- version: bigint
- dirty: boolean


--------------------
## Table: pegasys_connections
### Number of entries: 0

### Columns and data types:
- id: integer
- peer_id: character varying
- dial_attempt: timestamp with time zone
- latency: interval
- is_succeed: boolean
- error: character varying


--------------------
## Table: pegasys_neighbours
### Number of entries: 0

### Columns and data types:
- id: integer
- peer_id: character varying
- neighbour_peer_id: character varying
- created_at: timestamp with time zone
- crawl_start_at: timestamp with time zone


--------------------
## Table: multi_addresses
### Number of entries: 4'006'194

### Columns and data types:
- id: integer
- updated_at: timestamp with time zone
- created_at: timestamp with time zone
- maddr_sym_encrypted: text


--------------------
## Table: multi_addresses_x_ip_addresses
### Number of entries: 3'181'398

### Columns and data types:
- multi_address_id: integer
- ip_address_id: integer
- resolved_at: timestamp with time zone


--------------------
## Table: protocols
### Number of entries: 150

### Columns and data types:
- id: integer
- updated_at: timestamp with time zone
- created_at: timestamp with time zone
- protocol: text


--------------------
## Table: raw_visits
### Number of entries: 0

### Columns and data types:
- id: integer
- crawl_id: integer
- visit_started_at: timestamp with time zone
- visit_ended_at: timestamp with time zone
- dial_duration: interval
- connect_duration: interval
- crawl_duration: interval
- type: USER-DEFINED
- agent_version: text
- peer_multi_hash: text
- protocols: ARRAY
- multi_addresses: ARRAY
- error: USER-DEFINED
- error_message: text
- created_at: timestamp with time zone
- agent_version_id: integer
- protocol_ids: ARRAY


--------------------
## Table: neighbors
### Number of entries: 8'551'959

### Columns and data types:
- crawl_id: integer
- peer_id: integer
- neighbor_ids: ARRAY
- error_bits: smallint


